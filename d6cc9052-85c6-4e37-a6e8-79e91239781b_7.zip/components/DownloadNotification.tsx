
'use client';

import { useState, useEffect } from 'react';

interface NotificationProps {
  type: 'success' | 'error' | 'info';
  title: string;
  message: string;
  duration?: number;
  onClose?: () => void;
}

export function DownloadNotification({ 
  type, 
  title, 
  message, 
  duration = 3000, 
  onClose 
}: NotificationProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [isLeaving, setIsLeaving] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLeaving(true);
      setTimeout(() => {
        setIsVisible(false);
        onClose?.();
      }, 300);
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onClose]);

  const getNotificationStyles = () => {
    switch (type) {
      case 'success':
        return 'bg-emerald-500 border-emerald-400';
      case 'error':
        return 'bg-red-500 border-red-400';
      case 'info':
        return 'bg-blue-500 border-blue-400';
      default:
        return 'bg-slate-500 border-slate-400';
    }
  };

  const getIcon = () => {
    switch (type) {
      case 'success':
        return 'ri-check-line';
      case 'error':
        return 'ri-error-warning-line';
      case 'info':
        return 'ri-information-line';
      default:
        return 'ri-notification-line';
    }
  };

  if (!isVisible) return null;

  return (
    <div className={`
      fixed top-20 right-4 z-50 max-w-sm w-full
      ${getNotificationStyles()}
      text-white px-6 py-4 rounded-lg shadow-xl border
      transform transition-all duration-300 ease-in-out
      ${isLeaving ? 'translate-x-full opacity-0' : 'translate-x-0 opacity-100'}
    `}>
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0">
          <i className={`${getIcon()} text-xl`}></i>
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-sm mb-1">{title}</h4>
          <p className="text-sm opacity-90 leading-relaxed">{message}</p>
        </div>
        <button
          onClick={() => {
            setIsLeaving(true);
            setTimeout(() => {
              setIsVisible(false);
              onClose?.();
            }, 300);
          }}
          className="flex-shrink-0 text-white/70 hover:text-white transition-colors"
        >
          <i className="ri-close-line text-lg"></i>
        </button>
      </div>
    </div>
  );
}

export function NotificationManager() {
  const [notifications, setNotifications] = useState<Array<{
    id: string;
    type: 'success' | 'error' | 'info';
    title: string;
    message: string;
    duration?: number;
  }>>([]);

  const addNotification = (notification: Omit<typeof notifications[0], 'id'>) => {
    const id = Date.now().toString();
    setNotifications(prev => [...prev, { ...notification, id }]);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  // Expose global notification function
  useEffect(() => {
    (window as any).showDownloadNotification = addNotification;
    return () => {
      delete (window as any).showDownloadNotification;
    };
  }, []);

  return (
    <div className="fixed top-0 right-0 z-50 space-y-2 p-4">
      {notifications.map(notification => (
        <DownloadNotification
          key={notification.id}
          type={notification.type}
          title={notification.title}
          message={notification.message}
          duration={notification.duration}
          onClose={() => removeNotification(notification.id)}
        />
      ))}
    </div>
  );
}

// Utility functions for showing notifications
export const showNotification = {
  success: (title: string, message: string, duration?: number) => {
    if ((window as any).showDownloadNotification) {
      (window as any).showDownloadNotification({ type: 'success', title, message, duration });
    }
  },
  error: (title: string, message: string, duration?: number) => {
    if ((window as any).showDownloadNotification) {
      (window as any).showDownloadNotification({ type: 'error', title, message, duration });
    }
  },
  info: (title: string, message: string, duration?: number) => {
    if ((window as any).showDownloadNotification) {
      (window as any).showDownloadNotification({ type: 'info', title, message, duration });
    }
  }
};
