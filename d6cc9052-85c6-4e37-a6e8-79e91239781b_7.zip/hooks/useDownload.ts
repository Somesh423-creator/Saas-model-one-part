
'use client';

import { useState, useCallback } from 'react';
import { downloadManager } from '../lib/downloadManager';
import { showNotification } from '../components/DownloadNotification';

interface DownloadFile {
  id: number;
  name: string;
  size: string;
  category: string;
  date: string;
  status: string;
  url?: string;
}

interface DownloadProgress {
  fileId: number;
  progress: number;
  status: 'pending' | 'downloading' | 'completed' | 'failed';
  downloadId?: string;
}

export function useDownload() {
  const [downloadProgress, setDownloadProgress] = useState<Map<number, DownloadProgress>>(new Map());
  const [isDownloading, setIsDownloading] = useState(false);

  // Download single file
  const downloadFile = useCallback(async (file: DownloadFile) => {
    try {
      setIsDownloading(true);
      
      // Update progress
      setDownloadProgress(prev => new Map(prev).set(file.id, {
        fileId: file.id,
        progress: 0,
        status: 'downloading'
      }));

      // Show starting notification
      showNotification.info('Download Started', `Downloading ${file.name}...`);

      // Use download manager
      const result = await downloadManager.downloadFile(file);

      if (result.success) {
        // Update progress to completed
        setDownloadProgress(prev => new Map(prev).set(file.id, {
          fileId: file.id,
          progress: 100,
          status: 'completed',
          downloadId: result.downloadId
        }));

        // Show success notification
        showNotification.success(
          'Download Complete', 
          `${file.name} saved to ${result.result?.location || 'your device'}`
        );

        return result;
      }
    } catch (error) {
      // Update progress to failed
      setDownloadProgress(prev => new Map(prev).set(file.id, {
        fileId: file.id,
        progress: 0,
        status: 'failed'
      }));

      // Show error notification
      showNotification.error(
        'Download Failed', 
        error instanceof Error ? error.message : 'Unknown error occurred'
      );

      throw error;
    } finally {
      setIsDownloading(false);
    }
  }, []);

  // Download multiple files
  const downloadMultipleFiles = useCallback(async (files: DownloadFile[]) => {
    try {
      setIsDownloading(true);

      // Initialize progress for all files
      const newProgress = new Map(downloadProgress);
      files.forEach(file => {
        newProgress.set(file.id, {
          fileId: file.id,
          progress: 0,
          status: 'pending'
        });
      });
      setDownloadProgress(newProgress);

      // Show bulk download notification
      showNotification.info('Bulk Download', `Starting download of ${files.length} files...`);

      // Use bulk download from manager
      const results = await downloadManager.bulkDownload(files);

      let successCount = 0;
      let failCount = 0;

      // Process results
      results.forEach((result, index) => {
        const file = files[index];
        
        if (result.status === 'fulfilled') {
          successCount++;
          setDownloadProgress(prev => new Map(prev).set(file.id, {
            fileId: file.id,
            progress: 100,
            status: 'completed'
          }));
        } else {
          failCount++;
          setDownloadProgress(prev => new Map(prev).set(file.id, {
            fileId: file.id,
            progress: 0,
            status: 'failed'
          }));
        }
      });

      // Show completion notification
      if (successCount > 0 && failCount === 0) {
        showNotification.success(
          'Bulk Download Complete',
          `Successfully downloaded ${successCount} files`
        );
      } else if (successCount > 0 && failCount > 0) {
        showNotification.info(
          'Bulk Download Partial',
          `Downloaded ${successCount} files, ${failCount} failed`
        );
      } else {
        showNotification.error(
          'Bulk Download Failed',
          `Failed to download ${failCount} files`
        );
      }

      return results;
    } catch (error) {
      showNotification.error(
        'Bulk Download Error',
        'Failed to complete bulk download'
      );
      throw error;
    } finally {
      setIsDownloading(false);
    }
  }, [downloadProgress]);

  // Get download progress for a file
  const getFileProgress = useCallback((fileId: number) => {
    return downloadProgress.get(fileId);
  }, [downloadProgress]);

  // Clear completed downloads
  const clearCompleted = useCallback(() => {
    const newProgress = new Map();
    downloadProgress.forEach((progress, fileId) => {
      if (progress.status !== 'completed') {
        newProgress.set(fileId, progress);
      }
    });
    setDownloadProgress(newProgress);
    
    // Also clear from download manager
    downloadManager.clearCompleted();
  }, [downloadProgress]);

  // Get download statistics
  const getDownloadStats = useCallback(() => {
    const stats = {
      total: downloadProgress.size,
      completed: 0,
      failed: 0,
      downloading: 0,
      pending: 0
    };

    downloadProgress.forEach(progress => {
      switch (progress.status) {
        case 'completed':
          stats.completed++;
          break;
        case 'failed':
          stats.failed++;
          break;
        case 'downloading':
          stats.downloading++;
          break;
        case 'pending':
          stats.pending++;
          break;
      }
    });

    return stats;
  }, [downloadProgress]);

  // Check if device supports advanced download features
  const getDownloadCapabilities = useCallback(() => {
    return downloadManager.isSupported;
  }, []);

  // Get all download history from manager
  const getDownloadHistory = useCallback(() => {
    return downloadManager.getAllDownloads();
  }, []);

  return {
    // State
    isDownloading,
    downloadProgress: Array.from(downloadProgress.values()),
    
    // Functions
    downloadFile,
    downloadMultipleFiles,
    getFileProgress,
    clearCompleted,
    getDownloadStats,
    getDownloadCapabilities,
    getDownloadHistory
  };
}

// Hook for download notifications
export function useDownloadNotifications() {
  const [notifications, setNotifications] = useState<Array<{
    id: string;
    type: 'success' | 'error' | 'info';
    title: string;
    message: string;
    timestamp: Date;
  }>>([]);

  const addNotification = useCallback((type: 'success' | 'error' | 'info', title: string, message: string) => {
    const notification = {
      id: Date.now().toString(),
      type,
      title,
      message,
      timestamp: new Date()
    };
    
    setNotifications(prev => [notification, ...prev].slice(0, 10)); // Keep only last 10
    return notification.id;
  }, []);

  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  return {
    notifications,
    addNotification,
    removeNotification,
    clearAllNotifications
  };
}
