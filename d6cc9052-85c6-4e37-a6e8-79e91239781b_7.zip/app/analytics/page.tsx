
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Analytics() {
  const [timeframe, setTimeframe] = useState('week');

  const stats = {
    week: {
      replies: 247,
      saved_hours: 12.3,
      response_rate: 98,
      top_triggers: [
        { keyword: 'PDF', count: 89, percentage: 36 },
        { keyword: 'price', count: 67, percentage: 27 },
        { keyword: 'book', count: 45, percentage: 18 },
        { keyword: 'help', count: 46, percentage: 19 }
      ]
    },
    month: {
      replies: 1247,
      saved_hours: 52.3,
      response_rate: 96,
      top_triggers: [
        { keyword: 'PDF', count: 389, percentage: 31 },
        { keyword: 'price', count: 267, percentage: 21 },
        { keyword: 'book', count: 245, percentage: 20 },
        { keyword: 'help', count: 346, percentage: 28 }
      ]
    },
    year: {
      replies: 15247,
      saved_hours: 652.3,
      response_rate: 94,
      top_triggers: [
        { keyword: 'PDF', count: 4389, percentage: 29 },
        { keyword: 'price', count: 3267, percentage: 21 },
        { keyword: 'book', count: 3245, percentage: 21 },
        { keyword: 'help', count: 4346, percentage: 29 }
      ]
    }
  };

  const currentStats = stats[timeframe] || stats.week;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative">
      {/* Professional Floating Elements */}
      <div className="absolute top-24 left-4 animate-pulse">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-bar-chart-line text-blue-400 text-sm"></i>
        </div>
      </div>
      <div className="absolute top-56 right-6 animate-pulse delay-200">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-line-chart-line text-emerald-400 text-sm"></i>
        </div>
      </div>

      {/* Professional Header */}
      <div className="fixed top-0 w-full z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-700/50 px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/" className="w-8 h-8 flex items-center justify-center bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700">
              <i className="ri-arrow-left-line text-white text-lg"></i>
            </Link>
            <div>
              <h1 className="text-white font-bold text-lg">Business Analytics</h1>
              <p className="text-slate-300 text-xs">Performance insights & metrics</p>
            </div>
          </div>
          <Link href="/downloads" className="w-8 h-8 flex items-center justify-center bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700">
            <i className="ri-download-line text-white text-lg"></i>
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 pb-24 px-4 space-y-6">
        {/* Professional Time Period Selector */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-2 border border-slate-700/50">
          <div className="grid grid-cols-3 gap-1">
            {['week', 'month', 'year'].map((period) => (
              <button
                key={period}
                onClick={() => setTimeframe(period)}
                className={`!rounded-button py-3 px-4 rounded-xl transition-all duration-300 ${
                  timeframe === period
                    ? 'bg-slate-700 text-white font-bold shadow-lg'
                    : 'text-slate-400 hover:bg-slate-700/50 hover:text-white'
                }`}
              >
                {period === 'week' ? 'This Week' : period === 'month' ? 'This Month' : 'This Year'}
              </button>
            ))}
          </div>
        </div>

        {/* Professional Key Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                <i className="ri-chat-check-line text-white text-xl"></i>
              </div>
              <div className="w-6 h-6 flex items-center justify-center bg-emerald-500/20 rounded-lg border border-emerald-500/30">
                <i className="ri-arrow-up-line text-emerald-400 text-sm"></i>
              </div>
            </div>
            <p className="text-white text-3xl font-bold mb-1">{currentStats.replies}</p>
            <p className="text-slate-300 text-sm">Messages Processed</p>
            <p className="text-emerald-400 text-xs mt-2">+23% from last period</p>
          </div>

          <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
                <i className="ri-time-line text-white text-xl"></i>
              </div>
              <div className="w-6 h-6 flex items-center justify-center bg-blue-500/20 rounded-lg border border-blue-500/30">
                <i className="ri-arrow-up-line text-blue-400 text-sm"></i>
              </div>
            </div>
            <p className="text-white text-3xl font-bold mb-1">{currentStats.saved_hours}</p>
            <p className="text-slate-300 text-sm">Hours Saved</p>
            <p className="text-blue-400 text-xs mt-2">+1.7h from last period</p>
          </div>
        </div>

        {/* Professional Response Rate */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-bold text-lg">Success Rate</h3>
            <span className="px-3 py-1 bg-emerald-500/20 rounded-lg text-emerald-400 text-sm font-medium border border-emerald-500/30">
              Excellent
            </span>
          </div>

          <div className="relative">
            <div className="w-32 h-32 mx-auto relative">
              <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120">
                <circle
                  cx="60"
                  cy="60"
                  r="54"
                  stroke="rgba(148, 163, 184, 0.2)"
                  strokeWidth="12"
                  fill="none"
                />
                <circle
                  cx="60"
                  cy="60"
                  r="54"
                  stroke="url(#gradient)"
                  strokeWidth="12"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={`${(currentStats.response_rate / 100) * 339.29} 339.29`}
                  className="transition-all duration-1000 ease-out"
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#10B981" />
                    <stop offset="100%" stopColor="#06B6D4" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-white text-2xl font-bold">{currentStats.response_rate}%</p>
                  <p className="text-slate-300 text-xs">Success Rate</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Professional Top Triggers */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
          <h3 className="text-white font-bold text-lg mb-4">Top Performing Triggers </h3>
          <div className="space-y-4">
            {currentStats.top_triggers.map((trigger, index) => (
              <div key={trigger.keyword} className="flex items-center space-x-4">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-lg flex items-center justify-center shadow-lg">
                  <span className="text-white text-sm font-bold">{index + 1}</span>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-white font-medium">{trigger.keyword}</p>
                    <span className="text-slate-300 text-sm">{trigger.count} replies</span>
                  </div>
                  <div className="bg-slate-700/50 rounded-full h-2">
                    <div
                      className="h-2 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full transition-all duration-1000"
                      style={{ width: `${trigger.percentage}%` }}
                    ></div>
                  </div>
                </div>
                <span className="text-slate-400 text-sm">{trigger.percentage}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Professional Engagement Chart */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
          <h3 className="text-white font-bold text-lg mb-4">Performance Analytics </h3>
          <div className="relative">
            <img
              src="https://readdy.ai/api/search-image?query=Professional%20business%20analytics%20dashboard%20with%20clean%20modern%20charts%20showing%20performance%20metrics%2C%20blue%20and%20indigo%20gradient%20colors%2C%20corporate%20style%20data%20visualization%2C%20professional%20presentation%2C%20white%20background%2C%20enterprise%20quality&width=600&height=300&seq=professional-analytics&orientation=landscape"
              alt="Professional Analytics Dashboard"
              className="w-full h-40 object-cover object-top rounded-xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/20 to-transparent rounded-xl"></div>
          </div>
        </div>

        {/* Professional Achievement Badge */}
        <div className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 backdrop-blur-md rounded-2xl p-6 border border-blue-500/30">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
              <i className="ri-award-line text-white text-2xl"></i>
            </div>
            <div>
              <h3 className="text-white font-bold text-lg">Professional Milestone!</h3>
              <p className="text-slate-200 text-sm">You've optimized over 10 hours of business operations this week. Your professional automation is delivering exceptional results! </p>
            </div>
          </div>
        </div>
      </div>

      {/* Professional Bottom Navigation */}
      <div className="fixed bottom-0 w-full bg-slate-900/90 backdrop-blur-md border-t border-slate-700/50 px-4 py-3">
        <div className="grid grid-cols-4 gap-0">
          <Link href="/" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-home-5-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Dashboard</span>
          </Link>
          <Link href="/templates" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-chat-3-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Templates</span>
          </Link>
          <div className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-bar-chart-fill text-white text-lg"></i>
            </div>
            <span className="text-white text-xs mt-1 font-medium">Analytics</span>
          </div>
          <Link href="/settings" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-user-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Account</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
