
'use client';

import Link from 'next/link';

export default function Settings() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative">
      {/* Professional Floating Elements */}
      <div className="absolute top-32 right-8 animate-pulse">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-settings-line text-blue-400 text-sm"></i>
        </div>
      </div>
      <div className="absolute top-48 left-4 animate-pulse delay-200">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-user-line text-indigo-400 text-sm"></i>
        </div>
      </div>

      {/* Professional Header */}
      <div className="fixed top-0 w-full z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-700/50 px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/" className="w-8 h-8 flex items-center justify-center bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700">
              <i className="ri-arrow-left-line text-white text-lg"></i>
            </Link>
            <div>
              <h1 className="text-white font-bold text-lg">Account Settings</h1>
              <p className="text-slate-300 text-xs">Manage your professional account</p>
            </div>
          </div>
          <div className="w-8 h-8 flex items-center justify-center bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700">
            <i className="ri-notification-line text-white text-lg"></i>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 pb-24 px-4 space-y-6">
        {/* Professional Profile Card */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
              <span className="text-white text-2xl font-bold">SM</span>
            </div>
            <div className="flex-1">
              <h2 className="text-white font-bold text-xl">Sarah Miller</h2>
              <p className="text-slate-300 text-sm">@sarahcoaches</p>
              <p className="text-slate-400 text-xs mt-1">Professional Business Coach</p>
            </div>
            <button className="!rounded-button px-4 py-2 bg-slate-700/50 backdrop-blur-sm rounded-xl border border-slate-600">
              <span className="text-white text-sm font-medium">Edit</span>
            </button>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-white text-lg font-bold">12.4K</p>
              <p className="text-slate-300 text-xs">Followers</p>
            </div>
            <div className="text-center">
              <p className="text-white text-lg font-bold">847</p>
              <p className="text-slate-300 text-xs">Messages/Month</p>
            </div>
            <div className="text-center">
              <p className="text-white text-lg font-bold">Pro</p>
              <p className="text-slate-300 text-xs">Plan</p>
            </div>
          </div>
        </div>

        {/* Professional Quick Settings */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
          <h3 className="text-white font-bold mb-4">System Preferences</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                  <i className="ri-notification-line text-white"></i>
                </div>
                <div>
                  <p className="text-white font-medium">Push Notifications</p>
                  <p className="text-slate-400 text-xs">Real-time message alerts</p>
                </div>
              </div>
              <div className="relative">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-12 h-6 bg-slate-700 rounded-full peer peer-checked:bg-gradient-to-r peer-checked:from-emerald-500 peer-checked:to-teal-500 transition-all duration-300 border border-slate-600"></div>
                <div className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform duration-300 peer-checked:translate-x-6 shadow-lg"></div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
                  <i className="ri-shield-check-line text-white"></i>
                </div>
                <div>
                  <p className="text-white font-medium">Smart Filtering</p>
                  <p className="text-slate-400 text-xs">AI-powered spam protection</p>
                </div>
              </div>
              <div className="relative">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-12 h-6 bg-slate-700 rounded-full peer peer-checked:bg-gradient-to-r peer-checked:from-blue-500 peer-checked:to-indigo-500 transition-all duration-300 border border-slate-600"></div>
                <div className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform duration-300 peer-checked:translate-x-6 shadow-lg"></div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-violet-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                  <i className="ri-time-line text-white"></i>
                </div>
                <div>
                  <p className="text-white font-medium">Business Hours</p>
                  <p className="text-slate-400 text-xs">Professional scheduling mode</p>
                </div>
              </div>
              <div className="relative">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-12 h-6 bg-slate-700 rounded-full peer peer-checked:bg-gradient-to-r peer-checked:from-violet-500 peer-checked:to-purple-500 transition-all duration-300 border border-slate-600"></div>
                <div className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform duration-300 peer-checked:translate-x-6 shadow-lg"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Professional Menu Options */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl border border-slate-700/50 overflow-hidden">
          <div className="divide-y divide-slate-700/50">
            <button className="w-full flex items-center space-x-4 p-6 text-left hover:bg-slate-700/30 transition-colors">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
                <i className="ri-instagram-line text-white"></i>
              </div>
              <div className="flex-1">
                <p className="text-white font-medium">Connected Accounts</p>
                <p className="text-slate-400 text-sm">Manage Instagram integrations</p>
              </div>
              <i className="ri-arrow-right-s-line text-slate-400 text-lg"></i>
            </button>

            <Link href="/pricing" className="w-full flex items-center space-x-4 p-6 text-left hover:bg-slate-700/30 transition-colors">
              <div className="w-10 h-10 bg-gradient-to-r from-violet-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                <i className="ri-crown-line text-white"></i>
              </div>
              <div className="flex-1">
                <p className="text-white font-medium">Upgrade Plan</p>
                <p className="text-slate-400 text-sm">Unlock enterprise features</p>
              </div>
              <div className="px-2 py-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg shadow-lg">
                <span className="text-xs font-bold text-white">PRO</span>
              </div>
            </Link>

            <Link href="/downloads" className="w-full flex items-center space-x-4 p-6 text-left hover:bg-slate-700/30 transition-colors">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                <i className="ri-download-line text-white"></i>
              </div>
              <div className="flex-1">
                <p className="text-white font-medium">Downloads & Files</p>
                <p className="text-slate-400 text-sm">Access your resources</p>
              </div>
              <i className="ri-arrow-right-s-line text-slate-400 text-lg"></i>
            </Link>

            <button className="w-full flex items-center space-x-4 p-6 text-left hover:bg-slate-700/30 transition-colors">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-amber-500 rounded-xl flex items-center justify-center shadow-lg">
                <i className="ri-question-line text-white"></i>
              </div>
              <div className="flex-1">
                <p className="text-white font-medium">Support Center</p>
                <p className="text-slate-400 text-sm">Get professional assistance</p>
              </div>
              <i className="ri-arrow-right-s-line text-slate-400 text-lg"></i>
            </button>

            <button className="w-full flex items-center space-x-4 p-6 text-left hover:bg-slate-700/30 transition-colors">
              <div className="w-10 h-10 bg-gradient-to-r from-slate-500 to-slate-600 rounded-xl flex items-center justify-center shadow-lg">
                <i className="ri-logout-box-line text-white"></i>
              </div>
              <div className="flex-1">
                <p className="text-white font-medium">Sign Out</p>
                <p className="text-slate-400 text-sm">Secure account logout</p>
              </div>
              <i className="ri-arrow-right-s-line text-slate-400 text-lg"></i>
            </button>
          </div>
        </div>

        {/* Professional App Info */}
        <div className="text-center space-y-2">
          <p className="text-slate-400 text-sm">InstaPing Professional v2.1.0</p>
          <p className="text-slate-500 text-xs">Enterprise-grade Instagram automation</p>
        </div>
      </div>

      {/* Professional Bottom Navigation */}
      <div className="fixed bottom-0 w-full bg-slate-900/90 backdrop-blur-md border-t border-slate-700/50 px-4 py-3">
        <div className="grid grid-cols-4 gap-0">
          <Link href="/" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-home-5-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Dashboard</span>
          </Link>
          <Link href="/templates" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-chat-3-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Templates</span>
          </Link>
          <Link href="/analytics" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-bar-chart-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Analytics</span>
          </Link>
          <div className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-user-fill text-white text-lg"></i>
            </div>
            <span className="text-white text-xs mt-1 font-medium">Account</span>
          </div>
        </div>
      </div>
    </div>
  );
}
