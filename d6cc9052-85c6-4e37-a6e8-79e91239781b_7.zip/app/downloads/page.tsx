
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function Downloads() {
  const [downloadHistory, setDownloadHistory] = useState([
    { id: 1, name: 'Business Guide 2024.pdf', size: '2.4 MB', date: '2024-01-15', category: 'Guide', status: 'completed', url: '/files/business-guide-2024.pdf' },
    { id: 2, name: 'Instagram Templates Pack.zip', size: '5.1 MB', date: '2024-01-14', category: 'Templates', status: 'completed', url: '/files/instagram-templates.zip' },
    { id: 3, name: 'Analytics Report Q4.pdf', size: '1.8 MB', date: '2024-01-13', category: 'Report', status: 'completed', url: '/files/analytics-report-q4.pdf' },
    { id: 4, name: 'Brand Assets Package.zip', size: '12.3 MB', date: '2024-01-12', category: 'Assets', status: 'completed', url: '/files/brand-assets.zip' },
    { id: 5, name: 'Training Materials.pdf', size: '3.7 MB', date: '2024-01-11', category: 'Training', status: 'completed', url: '/files/training-materials.pdf' },
    { id: 6, name: 'Auto Reply Scripts.txt', size: '0.5 MB', date: '2024-01-10', category: 'Templates', status: 'completed', url: '/files/auto-reply-scripts.txt' },
    { id: 7, name: 'User Manual.pdf', size: '4.2 MB', date: '2024-01-09', category: 'Guide', status: 'completed', url: '/files/user-manual.pdf' },
    { id: 8, name: 'Monthly Report Jan.pdf', size: '2.1 MB', date: '2024-01-08', category: 'Report', status: 'completed', url: '/files/monthly-report-jan.pdf' }
  ]);

  const [selectedCategory, setSelectedCategory] = useState('all');
  const [downloadQueue, setDownloadQueue] = useState([]);
  const [isDownloading, setIsDownloading] = useState(false);

  const categories = ['all', 'Guide', 'Templates', 'Report', 'Assets', 'Training'];

  const filteredDownloads = selectedCategory === 'all' 
    ? downloadHistory 
    : downloadHistory.filter(item => item.category === selectedCategory);

  // Mobile download function with storage API
  const handleMobileDownload = async (file) => {
    try {
      setIsDownloading(true);
      
      // Check if it's a mobile device
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      
      if (isMobile && 'navigator' in window && 'storage' in navigator && navigator.storage.persist) {
        // Request persistent storage for mobile
        const persistent = await navigator.storage.persist();
        console.log('Persistent storage:', persistent);
      }

      // Create file content based on type
      let fileContent;
      let mimeType;
      
      switch (file.category) {
        case 'Guide':
        case 'Report':
        case 'Training':
          fileContent = generatePDFContent(file);
          mimeType = 'application/pdf';
          break;
        case 'Templates':
        case 'Assets':
          fileContent = generateZipContent(file);
          mimeType = 'application/zip';
          break;
        default:
          fileContent = generateTextContent(file);
          mimeType = 'text/plain';
      }

      // Create blob with proper MIME type
      const blob = new Blob([fileContent], { type: mimeType });
      
      // For mobile devices, use different download strategy
      if (isMobile) {
        // Try to save to mobile storage using File System Access API (if supported)
        if ('showSaveFilePicker' in window) {
          try {
            const fileHandle = await window.showSaveFilePicker({
              suggestedName: file.name,
              types: [{
                description: file.category + ' files',
                accept: {
                  [mimeType]: [getFileExtension(file.name)]
                }
              }]
            });
            const writable = await fileHandle.createWritable();
            await writable.write(blob);
            await writable.close();
            
            showDownloadSuccess(file.name, 'Mobile Storage');
          } catch (err) {
            // Fallback to regular download
            downloadToDevice(blob, file.name);
          }
        } else {
          // Use regular download for mobile
          downloadToDevice(blob, file.name);
        }
      } else {
        // Desktop download
        downloadToDevice(blob, file.name);
      }

      // Update download history
      updateDownloadHistory(file.id);
      
    } catch (error) {
      console.error('Download failed:', error);
      showDownloadError(file.name);
    } finally {
      setIsDownloading(false);
    }
  };

  // Regular download function
  const downloadToDevice = (blob, filename) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showDownloadSuccess(filename, 'Downloads Folder');
  };

  // Generate different file contents
  const generatePDFContent = (file) => {
    return `%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
>>
endobj

4 0 obj
<<
/Length 100
>>
stream
BT
/F1 12 Tf
100 700 Td
(${file.name} - InstaPing Professional) Tj
0 -20 Td
(Generated on: ${new Date().toLocaleDateString()}) Tj
0 -20 Td
(Category: ${file.category}) Tj
0 -20 Td
(This is a sample ${file.category.toLowerCase()} file for your InstaPing app.) Tj
ET
endstream
endobj

xref
0 5
0000000000 65535 f 
0000000010 00000 n 
0000000079 00000 n 
0000000136 00000 n 
0000000217 00000 n 
trailer
<<
/Size 5
/Root 1 0 R
>>
startxref
369
%%EOF`;
  };

  const generateZipContent = (file) => {
    // Simple text content for ZIP demo
    return `InstaPing ${file.category} Package
=================================

File: ${file.name}
Generated: ${new Date().toISOString()}
Category: ${file.category}

Contents:
- Template files
- Configuration settings
- Usage instructions
- Example implementations

This package contains professional ${file.category.toLowerCase()} for your InstaPing automation system.

For support, contact: support@instaping.com`;
  };

  const generateTextContent = (file) => {
    return `InstaPing ${file.category} File
=========================

File: ${file.name}
Generated: ${new Date().toISOString()}
Category: ${file.category}
Size: ${file.size}

This is a sample ${file.category.toLowerCase()} file generated by InstaPing Professional.

Content includes:
- Professional templates
- Automation scripts  
- Configuration files
- Documentation

Thank you for using InstaPing Professional!
Visit: https://instaping.com`;
  };

  const getFileExtension = (filename) => {
    return '.' + filename.split('.').pop();
  };

  const updateDownloadHistory = (fileId) => {
    setDownloadHistory(prev => 
      prev.map(file => 
        file.id === fileId 
          ? { ...file, status: 'downloaded', lastDownload: new Date().toISOString() }
          : file
      )
    );
  };

  const showDownloadSuccess = (filename, location) => {
    // You can replace this with a proper toast notification
    const notification = document.createElement('div');
    notification.className = 'fixed top-20 right-4 bg-emerald-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.innerHTML = `
      <div class="flex items-center space-x-2">
        <i class="ri-check-line"></i>
        <div>
          <div class="font-semibold">${filename}</div>
          <div class="text-sm opacity-90">Saved to ${location}</div>
        </div>
      </div>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 3000);
  };

  const showDownloadError = (filename) => {
    const notification = document.createElement('div');
    notification.className = 'fixed top-20 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.innerHTML = `
      <div class="flex items-center space-x-2">
        <i class="ri-error-warning-line"></i>
        <div>
          <div class="font-semibold">Download Failed</div>
          <div class="text-sm opacity-90">${filename}</div>
        </div>
      </div>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 3000);
  };

  // Bulk download function
  const handleBulkDownload = async () => {
    setIsDownloading(true);
    for (const file of filteredDownloads) {
      await handleMobileDownload(file);
      await new Promise(resolve => setTimeout(resolve, 500)); // Small delay between downloads
    }
    setIsDownloading(false);
  };

  const getCategoryIcon = (category) => {
    switch(category) {
      case 'Guide': return 'ri-book-line';
      case 'Templates': return 'ri-layout-line';
      case 'Report': return 'ri-file-chart-line';
      case 'Assets': return 'ri-image-line';
      case 'Training': return 'ri-graduation-cap-line';
      default: return 'ri-file-line';
    }
  };

  const getCategoryColor = (category) => {
    switch(category) {
      case 'Guide': return 'from-blue-500 to-indigo-500';
      case 'Templates': return 'from-purple-500 to-violet-500';
      case 'Report': return 'from-emerald-500 to-teal-500';
      case 'Assets': return 'from-orange-500 to-amber-500';
      case 'Training': return 'from-pink-500 to-rose-500';
      default: return 'from-slate-500 to-slate-600';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative">
      {/* Professional Floating Elements */}
      <div className="absolute top-24 right-8 animate-pulse">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-download-cloud-line text-blue-400 text-sm"></i>
        </div>
      </div>
      <div className="absolute top-48 left-6 animate-pulse delay-200">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-folder-line text-indigo-400 text-sm"></i>
        </div>
      </div>

      {/* Professional Header */}
      <div className="fixed top-0 w-full z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-700/50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="w-10 h-10 flex items-center justify-center bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700 hover:bg-slate-700/50 transition-colors">
              <i className="ri-arrow-left-line text-white text-lg"></i>
            </Link>
            <div>
              <h1 className="text-white font-bold text-xl">Download Center</h1>
              <p className="text-slate-300 text-sm">Mobile & Desktop Downloads</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={handleBulkDownload}
              disabled={isDownloading}
              className="!rounded-button px-4 py-2 bg-gradient-to-r from-purple-600 to-violet-600 rounded-lg text-white text-sm font-medium hover:scale-105 transition-transform disabled:opacity-50"
            >
              {isDownloading ? (
                <>
                  <i className="ri-loader-line animate-spin mr-2"></i>
                  Downloading...
                </>
              ) : (
                <>
                  <i className="ri-download-2-line mr-2"></i>
                  Bulk Download
                </>
              )}
            </button>
            <div className="px-4 py-2 bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700">
              <span className="text-slate-300 text-sm">{filteredDownloads.length} files</span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="pt-24 pb-24 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Mobile Download Info */}
          <div className="mb-8 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 backdrop-blur-md rounded-2xl p-6 border border-blue-500/20">
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
                <i className="ri-smartphone-line text-white text-xl"></i>
              </div>
              <div>
                <h3 className="text-white font-bold text-lg">Mobile Storage Ready</h3>
                <p className="text-blue-200 text-sm">Download directly to your device storage</p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div className="bg-blue-500/10 rounded-lg p-3">
                <i className="ri-android-line text-blue-400 text-2xl mb-2"></i>
                <p className="text-blue-200 text-xs">Android</p>
              </div>
              <div className="bg-blue-500/10 rounded-lg p-3">
                <i className="ri-apple-line text-blue-400 text-2xl mb-2"></i>
                <p className="text-blue-200 text-xs">iOS</p>
              </div>
              <div className="bg-blue-500/10 rounded-lg p-3">
                <i className="ri-computer-line text-blue-400 text-2xl mb-2"></i>
                <p className="text-blue-200 text-xs">Desktop</p>
              </div>
              <div className="bg-blue-500/10 rounded-lg p-3">
                <i className="ri-cloud-line text-blue-400 text-2xl mb-2"></i>
                <p className="text-blue-200 text-xs">Cloud Sync</p>
              </div>
            </div>
          </div>

          {/* Category Filter */}
          <div className="mb-8">
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-2 border border-slate-700/50 inline-flex overflow-x-auto">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-3 rounded-xl text-sm font-medium transition-all duration-300 whitespace-nowrap ${
                    selectedCategory === category
                      ? 'bg-slate-700 text-white shadow-lg'
                      : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  {category === 'all' ? 'All Files' : category}
                </button>
              ))}
            </div>
          </div>

          {/* Download Statistics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-4 border border-slate-700/50 text-center">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center mx-auto mb-3 shadow-lg">
                <i className="ri-download-line text-white text-lg"></i>
              </div>
              <h3 className="text-white font-bold text-xl mb-1">{downloadHistory.length}</h3>
              <p className="text-slate-300 text-xs">Total Files</p>
            </div>
            
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-4 border border-slate-700/50 text-center">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mx-auto mb-3 shadow-lg">
                <i className="ri-file-line text-white text-lg"></i>
              </div>
              <h3 className="text-white font-bold text-xl mb-1">
                {(downloadHistory.reduce((sum, file) => sum + parseFloat(file.size), 0)).toFixed(1)}
              </h3>
              <p className="text-slate-300 text-xs">Total MB</p>
            </div>
            
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-4 border border-slate-700/50 text-center">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-violet-500 rounded-xl flex items-center justify-center mx-auto mb-3 shadow-lg">
                <i className="ri-time-line text-white text-lg"></i>
              </div>
              <h3 className="text-white font-bold text-xl mb-1">8</h3>
              <p className="text-slate-300 text-xs">This Week</p>
            </div>
            
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-4 border border-slate-700/50 text-center">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-amber-500 rounded-xl flex items-center justify-center mx-auto mb-3 shadow-lg">
                <i className="ri-smartphone-line text-white text-lg"></i>
              </div>
              <h3 className="text-white font-bold text-xl mb-1">Mobile</h3>
              <p className="text-slate-300 text-xs">Ready</p>
            </div>
          </div>

          {/* Downloads List */}
          <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl border border-slate-700/50 overflow-hidden">
            <div className="p-6 border-b border-slate-700/50">
              <h3 className="text-white font-bold text-lg">Available Downloads</h3>
              <p className="text-slate-300 text-sm">Click to download to your device storage</p>
            </div>
            
            <div className="divide-y divide-slate-700/50">
              {filteredDownloads.map((file, index) => (
                <div
                  key={file.id}
                  className="p-4 hover:bg-slate-700/30 transition-colors group"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 bg-gradient-to-r ${getCategoryColor(file.category)} rounded-xl flex items-center justify-center shadow-lg`}>
                        <i className={`${getCategoryIcon(file.category)} text-white text-xl`}></i>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-white font-semibold text-base group-hover:text-blue-300 transition-colors truncate">
                          {file.name}
                        </h4>
                        <div className="flex items-center space-x-3 text-xs text-slate-400 mt-1">
                          <span>{file.size}</span>
                          <span>•</span>
                          <span>{file.date}</span>
                          <span className="px-2 py-1 bg-slate-700/50 rounded text-xs">
                            {file.category}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                        <span className="text-emerald-400 text-xs font-medium hidden sm:block">Ready</span>
                      </div>
                      <button
                        onClick={() => handleMobileDownload(file)}
                        disabled={isDownloading}
                        className="!rounded-button px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl text-white text-sm font-semibold hover:scale-105 transition-transform shadow-lg group-hover:shadow-xl disabled:opacity-50"
                      >
                        <i className="ri-download-line mr-1"></i>
                        <span className="hidden sm:inline">Download</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Storage Info */}
          <div className="mt-8 grid md:grid-cols-2 gap-6">
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-violet-500 rounded-xl flex items-center justify-center shadow-lg">
                  <i className="ri-cloud-line text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">Cloud Storage</h3>
                  <p className="text-slate-300 text-sm">Files synced across devices</p>
                </div>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-2 mb-2">
                <div className="bg-gradient-to-r from-purple-500 to-violet-500 h-2 rounded-full" style={{ width: '73%' }}></div>
              </div>
              <p className="text-slate-400 text-xs">73% of 1GB used • 270MB free</p>
            </div>
            
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                  <i className="ri-shield-check-line text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">Secure Downloads</h3>
                  <p className="text-slate-300 text-sm">Enterprise-grade security</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                  <span className="text-emerald-400 text-sm font-medium">SSL Encrypted</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                  <span className="text-blue-400 text-sm font-medium">Mobile Compatible</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 w-full bg-slate-900/95 backdrop-blur-md border-t border-slate-700/50">
        <div className="grid grid-cols-5 h-16">
          <Link href="/" className="flex flex-col items-center justify-center text-slate-400 hover:text-white transition-colors">
            <i className="ri-home-5-line text-lg mb-1"></i>
            <span className="text-xs font-medium">Home</span>
          </Link>
          <Link href="/templates" className="flex flex-col items-center justify-center text-slate-400 hover:text-white transition-colors">
            <i className="ri-chat-3-line text-lg mb-1"></i>
            <span className="text-xs font-medium">Templates</span>
          </Link>
          <Link href="/analytics" className="flex flex-col items-center justify-center text-slate-400 hover:text-white transition-colors">
            <i className="ri-bar-chart-line text-lg mb-1"></i>
            <span className="text-xs font-medium">Analytics</span>
          </Link>
          <div className="flex flex-col items-center justify-center text-white">
            <i className="ri-download-fill text-lg mb-1"></i>
            <span className="text-xs font-medium">Downloads</span>
          </div>
          <Link href="/settings" className="flex flex-col items-center justify-center text-slate-400 hover:text-white transition-colors">
            <i className="ri-user-line text-lg mb-1"></i>
            <span className="text-xs font-medium">Settings</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
