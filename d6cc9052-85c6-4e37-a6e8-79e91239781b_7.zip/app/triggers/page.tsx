
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Triggers() {
  const [newTrigger, setNewTrigger] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const [triggers] = useState([
    { id: 1, keyword: 'PDF', active: true, replies: 47, color: 'from-blue-500 to-indigo-500' },
    { id: 2, keyword: 'price', active: true, replies: 23, color: 'from-indigo-500 to-purple-500' },
    { id: 3, keyword: 'book', active: false, replies: 12, color: 'from-violet-500 to-purple-500' },
    { id: 4, keyword: 'coaching', active: true, replies: 31, color: 'from-emerald-500 to-teal-500' },
    { id: 5, keyword: 'help', active: true, replies: 18, color: 'from-orange-500 to-amber-500' },
  ]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative">
      {/* Professional Floating Elements */}
      <div className="absolute top-28 right-4 animate-pulse delay-100">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-flashlight-line text-blue-400 text-sm"></i>
        </div>
      </div>
      <div className="absolute top-52 left-6 animate-pulse delay-300">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-focus-line text-indigo-400 text-sm"></i>
        </div>
      </div>

      {/* Professional Header */}
      <div className="fixed top-0 w-full z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-700/50 px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/" className="w-8 h-8 flex items-center justify-center bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700">
              <i className="ri-arrow-left-line text-white text-lg"></i>
            </Link>
            <div>
              <h1 className="text-white font-bold text-lg">Smart Triggers</h1>
              <p className="text-slate-300 text-xs">Professional automation keywords</p>
            </div>
          </div>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="!rounded-button w-10 h-10 flex items-center justify-center bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg"
          >
            <i className={`ri-add-line text-white text-lg transition-transform duration-300 ${showAddForm ? 'rotate-45' : ''}`}></i>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 pb-24 px-4 space-y-6">
        {/* Professional Stats Overview */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
          <h2 className="text-white font-bold text-lg mb-4">Performance Overview </h2>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-white text-2xl font-bold">5</p>
              <p className="text-slate-300 text-xs">Active Triggers</p>
            </div>
            <div className="text-center">
              <p className="text-white text-2xl font-bold">131</p>
              <p className="text-slate-300 text-xs">Total Responses</p>
            </div>
            <div className="text-center">
              <p className="text-white text-2xl font-bold">94%</p>
              <p className="text-slate-300 text-xs">Success Rate</p>
            </div>
          </div>
        </div>

        {/* Professional Add New Trigger Form */}
        {showAddForm && (
          <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50 transform transition-all duration-300 scale-100">
            <h3 className="text-white font-bold mb-4">Create New Trigger</h3>
            <div className="space-y-4">
              <input
                type="text"
                value={newTrigger}
                onChange={(e) => setNewTrigger(e.target.value)}
                placeholder="Enter trigger keyword..."
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-400 backdrop-blur-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
              />
              <div className="flex space-x-3">
                <button className="!rounded-button flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl py-3 text-white font-semibold shadow-lg">
                  Add Trigger
                </button>
                <button
                  onClick={() => setShowAddForm(false)}
                  className="!rounded-button px-6 bg-slate-700/50 border border-slate-600 rounded-xl py-3 text-white font-medium"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Professional Triggers List */}
        <div className="space-y-4">
          {triggers.map((trigger, index) => (
            <div
              key={trigger.id}
              className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50 transform transition-all duration-300 hover:scale-105 hover:bg-slate-700/30"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${trigger.color} rounded-xl flex items-center justify-center shadow-lg`}>
                    <span className="text-white font-bold text-lg">{trigger.keyword.charAt(0).toUpperCase()}</span>
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg">"{trigger.keyword}"</h3>
                    <p className="text-slate-300 text-sm">{trigger.replies} automated responses</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <input type="checkbox" defaultChecked={trigger.active} className="sr-only peer" />
                    <div className="w-12 h-6 bg-slate-700 rounded-full peer peer-checked:bg-gradient-to-r peer-checked:from-emerald-500 peer-checked:to-teal-500 transition-all duration-300 border border-slate-600"></div>
                    <div className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform duration-300 peer-checked:translate-x-6 shadow-lg"></div>
                  </div>

                  <button className="!rounded-button w-8 h-8 flex items-center justify-center bg-slate-700/50 backdrop-blur-sm rounded-lg border border-slate-600">
                    <i className="ri-more-line text-white text-sm"></i>
                  </button>
                </div>
              </div>

              {/* Professional Performance Indicator */}
              <div className="flex items-center space-x-2 mt-4">
                <div className="flex-1 bg-slate-700/50 rounded-full h-2">
                  <div
                    className={`h-2 bg-gradient-to-r ${trigger.color} rounded-full transition-all duration-1000`}
                    style={{ width: `${Math.min((trigger.replies / 50) * 100, 100)}%` }}
                  ></div>
                </div>
                <span className="text-slate-300 text-xs font-medium">
                  {trigger.active ? ' Active' : ' Paused'}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Professional Pro Tip */}
        <div className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 backdrop-blur-md rounded-2xl p-6 border border-blue-500/30">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-lightbulb-line text-blue-400 text-xl"></i>
            </div>
            <div>
              <h3 className="text-white font-bold mb-1">Professional Tip!</h3>
              <p className="text-slate-200 text-sm">Use industry-specific keywords like "consultation", "pricing", or "booking" for higher conversion rates. Professional automation drives better business results! </p>
            </div>
          </div>
        </div>
      </div>

      {/* Professional Bottom Navigation */}
      <div className="fixed bottom-0 w-full bg-slate-900/90 backdrop-blur-md border-t border-slate-700/50 px-4 py-3">
        <div className="grid grid-cols-4 gap-0">
          <Link href="/" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-home-5-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Dashboard</span>
          </Link>
          <Link href="/templates" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-chat-3-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Templates</span>
          </Link>
          <Link href="/analytics" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-bar-chart-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Analytics</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-user-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Account</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
