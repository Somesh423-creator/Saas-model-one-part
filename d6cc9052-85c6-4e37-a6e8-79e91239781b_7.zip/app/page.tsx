
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function InstaPingHome() {
  const [animateBubbles, setAnimateBubbles] = useState(true);
  const [botWaving, setBotWaving] = useState(false);
  const [replyCount, setReplyCount] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setReplyCount(prev => prev < 247 ? prev + 1 : 247);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const waveInterval = setInterval(() => {
      setBotWaving(true);
      setTimeout(() => setBotWaving(false), 1000);
    }, 3000);
    return () => clearInterval(waveInterval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 overflow-hidden relative">
      {/* Professional Floating Elements */}
      <div className="absolute top-20 left-6 animate-pulse delay-100">
        <div className="w-8 h-8 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-instagram-line text-blue-400 text-lg"></i>
        </div>
      </div>
      <div className="absolute top-32 right-8 animate-pulse delay-300">
        <div className="w-8 h-8 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-message-2-fill text-indigo-400 text-lg"></i>
        </div>
      </div>
      <div className="absolute top-60 left-4 animate-pulse delay-500">
        <div className="w-8 h-8 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-chat-check-line text-emerald-400 text-lg"></i>
        </div>
      </div>

      {/* Professional Header */}
      <div className="fixed top-0 w-full z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-700/50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg transform transition-transform duration-500 ${botWaving ? 'scale-110' : ''}`}>
              <span className={`text-xl transform transition-transform duration-500 ${botWaving ? 'animate-bounce' : ''}`}>🤖</span>
            </div>
            <div>
              <h1 className="text-white font-bold text-2xl font-[family-name:var(--font-pacifico)]">InstaPing</h1>
              <p className="text-slate-300 text-sm">Professional Auto-Reply Solution</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/pricing" className="!rounded-button px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl hover:scale-105 transition-transform shadow-lg">
              <span className="text-white font-semibold">Upgrade Pro</span>
            </Link>
            <div className="w-10 h-10 flex items-center justify-center bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700">
              <i className="ri-settings-3-line text-slate-300 text-lg"></i>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="pt-24 pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-4">
              Professional <span className="bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">Instagram Automation</span>
            </h2>
            <p className="text-slate-300 text-lg md:text-xl max-w-3xl mx-auto mb-8">
              Enterprise-grade DM automation for businesses. Scale your Instagram engagement with professional auto-reply solutions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/pricing" className="!rounded-button px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl hover:scale-105 transition-transform shadow-lg">
                <span className="text-white font-semibold text-lg">Start Free Trial</span>
              </Link>
              <Link href="/templates" className="!rounded-button px-8 py-4 bg-slate-800/50 backdrop-blur-md border border-slate-700 rounded-xl hover:bg-slate-700/50 transition-colors">
                <span className="text-white font-semibold text-lg">View Demo</span>
              </Link>
            </div>
          </div>

          {/* Professional Stats Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-8 border border-slate-700/50 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-chat-check-line text-white text-2xl"></i>
              </div>
              <h3 className="text-white font-bold text-3xl mb-2">{replyCount}</h3>
              <p className="text-slate-300">Messages Processed</p>
            </div>
            
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-8 border border-slate-700/50 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-flashlight-line text-white text-2xl"></i>
              </div>
              <h3 className="text-white font-bold text-3xl mb-2">98%</h3>
              <p className="text-slate-300">Response Accuracy</p>
            </div>
            
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-8 border border-slate-700/50 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-violet-500 to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-time-line text-white text-2xl"></i>
              </div>
              <h3 className="text-white font-bold text-3xl mb-2">12.3</h3>
              <p className="text-slate-300">Hours Saved Daily</p>
            </div>
          </div>

          {/* Feature Grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Professional Chat Preview */}
            <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-8 border border-slate-700/50">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-white font-bold text-xl">Live Automation 💼</h3>
                <span className="px-4 py-2 bg-emerald-500/20 rounded-lg text-emerald-300 text-sm font-medium border border-emerald-500/30">Active</span>
              </div>
              
              <div className="space-y-4">
                <div className={`flex justify-start transform transition-all duration-500 ${animateBubbles ? 'translate-x-0 opacity-100' : '-translate-x-4 opacity-0'}`}>
                  <div className="bg-slate-700/70 rounded-2xl rounded-bl-md px-6 py-4 max-w-xs border border-slate-600/50">
                    <p className="text-slate-100">Do you have the business PDF guide?</p>
                    <p className="text-slate-400 text-xs mt-2">2:34 PM</p>
                  </div>
                </div>
                
                <div className={`flex justify-end transform transition-all duration-500 delay-1000 ${animateBubbles ? 'translate-x-0 opacity-100' : 'translate-x-4 opacity-0'}`}>
                  <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl rounded-br-md px-6 py-4 max-w-xs shadow-lg">
                    <p className="text-white">Yes! Here's your business guide 📊 Download link sent to your DMs.</p>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="text-blue-200 text-xs">Auto-reply</span>
                      <div className="w-4 h-4 flex items-center justify-center">
                        <i className="ri-robot-line text-blue-200 text-xs"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Professional Quick Actions */}
            <div className="space-y-6">
              <Link href="/templates" className="!rounded-button block bg-slate-800/50 backdrop-blur-md border border-slate-700/50 p-6 rounded-2xl hover:bg-slate-700/50 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
                    <i className="ri-edit-2-line text-white text-2xl"></i>
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg mb-1">Template Manager</h3>
                    <p className="text-slate-300">Create professional auto-responses</p>
                  </div>
                </div>
              </Link>
              
              <Link href="/triggers" className="!rounded-button block bg-slate-800/50 backdrop-blur-md border border-slate-700/50 p-6 rounded-2xl hover:bg-slate-700/50 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-r from-violet-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                    <i className="ri-flashlight-line text-white text-2xl"></i>
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg mb-1">Smart Triggers</h3>
                    <p className="text-slate-300">Configure keyword automation</p>
                  </div>
                </div>
              </Link>
              
              <Link href="/analytics" className="!rounded-button block bg-slate-800/50 backdrop-blur-md border border-slate-700/50 p-6 rounded-2xl hover:bg-slate-700/50 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                    <i className="ri-bar-chart-line text-white text-2xl"></i>
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg mb-1">Business Analytics</h3>
                    <p className="text-slate-300">Track performance metrics</p>
                  </div>
                </div>
              </Link>
            </div>
          </div>

          {/* Professional Status Toggle */}
          <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-8 border border-slate-700/50 text-center">
            <div className="flex items-center justify-center space-x-6">
              <div>
                <h3 className="text-white font-bold text-xl mb-2">Automation Status</h3>
                <p className="text-slate-300">Professional auto-reply system is active</p>
              </div>
              <div className="relative">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-16 h-8 bg-slate-700 rounded-full peer peer-checked:bg-gradient-to-r peer-checked:from-blue-600 peer-checked:to-indigo-600 transition-all duration-300 border border-slate-600"></div>
                <div className="absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform duration-300 peer-checked:translate-x-8 shadow-lg"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Professional Bottom Navigation */}
      <div className="fixed bottom-0 w-full bg-slate-900/90 backdrop-blur-md border-t border-slate-700/50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2 text-white">
              <i className="ri-home-5-fill text-lg"></i>
              <span className="font-medium">Dashboard</span>
            </div>
            <Link href="/templates" className="flex items-center space-x-2 text-slate-400 hover:text-white transition-colors">
              <i className="ri-chat-3-line text-lg"></i>
              <span className="font-medium">Templates</span>
            </Link>
            <Link href="/analytics" className="flex items-center space-x-2 text-slate-400 hover:text-white transition-colors">
              <i className="ri-bar-chart-line text-lg"></i>
              <span className="font-medium">Analytics</span>
            </Link>
            <Link href="/pricing" className="flex items-center space-x-2 text-slate-400 hover:text-white transition-colors">
              <i className="ri-vip-crown-line text-lg"></i>
              <span className="font-medium">Plans</span>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/settings" className="flex items-center space-x-2 text-slate-400 hover:text-white transition-colors">
              <i className="ri-user-line text-lg"></i>
              <span className="font-medium">Account</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
