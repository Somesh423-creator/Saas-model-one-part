
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Pricing() {
  const [isYearly, setIsYearly] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('pro');

  const plans = [
    {
      id: 'free',
      name: 'Starter',
      icon: '🚀',
      price: { monthly: 0, yearly: 0 },
      features: [
        '50 auto-replies per month',
        '3 reply templates',
        '5 trigger keywords',
        'Basic analytics dashboard',
        'Email support'
      ],
      buttonText: 'Start Free',
      gradient: 'from-slate-600 to-slate-700',
      popular: false
    },
    {
      id: 'pro',
      name: 'Professional',
      icon: '💼',
      price: { monthly: 29, yearly: 290 },
      features: [
        'Unlimited auto-replies',
        'Unlimited templates',
        'Advanced trigger system',
        'Detailed analytics & reports',
        'Priority support',
        'Custom delay settings',
        'Instagram insights integration',
        'Team collaboration tools'
      ],
      buttonText: 'Go Professional',
      gradient: 'from-blue-600 to-indigo-600',
      popular: true
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      icon: '🏢',
      price: { monthly: 79, yearly: 790 },
      features: [
        'Everything in Professional',
        'AI-powered smart replies',
        'Multi-account management',
        'Advanced team collaboration',
        'Custom integrations & API',
        'White-label solutions',
        'Dedicated account manager',
        '24/7 phone support',
        'Custom SLA agreements'
      ],
      buttonText: 'Contact Sales',
      gradient: 'from-violet-600 to-purple-600',
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Professional Floating Elements */}
      <div className="absolute top-20 left-8 animate-pulse">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-money-dollar-circle-line text-emerald-400 text-sm"></i>
        </div>
      </div>
      <div className="absolute top-40 right-6 animate-pulse delay-200">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-award-line text-blue-400 text-sm"></i>
        </div>
      </div>

      {/* Professional Header */}
      <div className="fixed top-0 w-full z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-700/50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="w-10 h-10 flex items-center justify-center bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700 hover:bg-slate-700/50 transition-colors">
              <i className="ri-arrow-left-line text-white text-lg"></i>
            </Link>
            <div>
              <h1 className="text-white font-bold text-xl">Professional Plans</h1>
              <p className="text-slate-300 text-sm">Choose your business solution</p>
            </div>
          </div>
          <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
            <span className="text-lg">🤖</span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="pt-24 pb-12 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Scale Your <span className="bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">Business Growth</span>
            </h2>
            <p className="text-slate-300 text-lg md:text-xl max-w-3xl mx-auto mb-8">
              Professional Instagram automation solutions designed for businesses that demand excellence and scalability.
            </p>

            {/* Professional Billing Toggle */}
            <div className="inline-flex items-center bg-slate-800/50 backdrop-blur-md rounded-xl p-1 mb-8 border border-slate-700">
              <button
                onClick={() => setIsYearly(false)}
                className={`px-6 py-3 rounded-lg text-sm font-medium transition-all duration-300 ${!isYearly ? 'bg-slate-700 text-white shadow-lg' : 'text-slate-300 hover:text-white'}`}
              >
                Monthly Billing
              </button>
              <button
                onClick={() => setIsYearly(true)}
                className={`px-6 py-3 rounded-lg text-sm font-medium transition-all duration-300 ${isYearly ? 'bg-slate-700 text-white shadow-lg' : 'text-slate-300 hover:text-white'}`}
              >
                Annual Billing <span className="ml-1 px-2 py-1 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg text-xs text-white">Save 17%</span>
              </button>
            </div>
          </div>

          {/* Professional Pricing Cards */}
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className={`relative bg-slate-800/50 backdrop-blur-md rounded-2xl p-8 border transition-all duration-300 hover:scale-105 hover:bg-slate-700/50 ${plan.popular ? 'border-blue-500 ring-2 ring-blue-500/30 shadow-xl shadow-blue-500/20' : 'border-slate-700/50'}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg shadow-lg">
                      <span className="text-sm font-bold text-white">MOST POPULAR</span>
                    </div>
                  </div>
                )}

                <div className="text-center mb-8">
                  <div className={`w-16 h-16 bg-gradient-to-r ${plan.gradient} rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                    <span className="text-2xl">{plan.icon}</span>
                  </div>
                  <h3 className="text-white font-bold text-xl mb-2">{plan.name}</h3>
                  <div className="mb-4">
                    <span className="text-white text-4xl font-bold">
                      ${isYearly ? plan.price.yearly : plan.price.monthly}
                    </span>
                    <span className="text-slate-400 text-sm ml-2">
                      {plan.price.monthly === 0 ? 'forever' : isYearly ? '/year' : '/month'}
                    </span>
                  </div>
                  {isYearly && plan.price.monthly > 0 && (
                    <p className="text-emerald-400 text-sm font-medium">
                      Save ${(plan.price.monthly * 12) - plan.price.yearly}/year
                    </p>
                  )}
                </div>

                <div className="space-y-4 mb-8">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="w-5 h-5 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <i className="ri-check-line text-white text-xs"></i>
                      </div>
                      <span className="text-slate-200 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setSelectedPlan(plan.id)}
                  className={`!rounded-button w-full py-4 rounded-xl font-semibold text-white transition-all duration-300 hover:scale-105 shadow-lg ${
                    plan.id === 'free' 
                      ? 'bg-slate-700/70 hover:bg-slate-600/70 border border-slate-600' 
                      : `bg-gradient-to-r ${plan.gradient} hover:shadow-xl`
                  }`}
                >
                  {plan.buttonText}
                </button>
              </div>
            ))}
          </div>

          {/* Professional Features Comparison */}
          <div className="mt-16 bg-slate-800/50 backdrop-blur-md rounded-2xl p-8 border border-slate-700/50">
            <h3 className="text-white font-bold text-2xl text-center mb-8">Feature Comparison</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-white font-semibold py-4 pr-8">Features</th>
                    <th className="text-white font-semibold py-4 px-4 text-center">Starter</th>
                    <th className="text-white font-semibold py-4 px-4 text-center">Professional</th>
                    <th className="text-white font-semibold py-4 px-4 text-center">Enterprise</th>
                  </tr>
                </thead>
                <tbody className="text-slate-300 text-sm">
                  <tr className="border-b border-slate-700/50">
                    <td className="py-4 pr-8">Monthly auto-replies</td>
                    <td className="py-4 px-4 text-center">50</td>
                    <td className="py-4 px-4 text-center">Unlimited</td>
                    <td className="py-4 px-4 text-center">Unlimited</td>
                  </tr>
                  <tr className="border-b border-slate-700/50">
                    <td className="py-4 pr-8">Reply templates</td>
                    <td className="py-4 px-4 text-center">3</td>
                    <td className="py-4 px-4 text-center">Unlimited</td>
                    <td className="py-4 px-4 text-center">Unlimited</td>
                  </tr>
                  <tr className="border-b border-slate-700/50">
                    <td className="py-4 pr-8">AI-powered responses</td>
                    <td className="py-4 px-4 text-center">❌</td>
                    <td className="py-4 px-4 text-center">❌</td>
                    <td className="py-4 px-4 text-center">✅</td>
                  </tr>
                  <tr className="border-b border-slate-700/50">
                    <td className="py-4 pr-8">Multi-account support</td>
                    <td className="py-4 px-4 text-center">❌</td>
                    <td className="py-4 px-4 text-center">❌</td>
                    <td className="py-4 px-4 text-center">✅</td>
                  </tr>
                  <tr>
                    <td className="py-4 pr-8">Dedicated support</td>
                    <td className="py-4 px-4 text-center">❌</td>
                    <td className="py-4 px-4 text-center">✅</td>
                    <td className="py-4 px-4 text-center">✅</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* FAQ Section */}
          <div className="mt-16 text-center">
            <h3 className="text-white font-bold text-2xl mb-8">Frequently Asked Questions</h3>
            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <div className="bg-slate-800/50 backdrop-blur-md rounded-xl p-6 border border-slate-700/50">
                <h4 className="text-white font-bold mb-3">Can I upgrade anytime?</h4>
                <p className="text-slate-300 text-sm">Yes! Upgrade or downgrade your plan instantly. Changes are effective immediately with prorated billing.</p>
              </div>
              <div className="bg-slate-800/50 backdrop-blur-md rounded-xl p-6 border border-slate-700/50">
                <h4 className="text-white font-bold mb-3">Is there a free trial?</h4>
                <p className="text-slate-300 text-sm">Our Starter plan is free forever with 50 monthly replies. No credit card required to get started.</p>
              </div>
              <div className="bg-slate-800/50 backdrop-blur-md rounded-xl p-6 border border-slate-700/50">
                <h4 className="text-white font-bold mb-3">What payment methods are accepted?</h4>
                <p className="text-slate-300 text-sm">We accept all major credit cards, PayPal, and wire transfers for enterprise accounts.</p>
              </div>
              <div className="bg-slate-800/50 backdrop-blur-md rounded-xl p-6 border border-slate-700/50">
                <h4 className="text-white font-bold mb-3">Can I cancel anytime?</h4>
                <p className="text-slate-300 text-sm">Absolutely! Cancel your subscription at any time with no penalties or hidden fees.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Professional Bottom Navigation */}
      <div className="fixed bottom-0 w-full bg-slate-900/90 backdrop-blur-md border-t border-slate-700/50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link href="/" className="flex items-center space-x-2 text-slate-400 hover:text-white transition-colors">
              <i className="ri-home-5-line text-lg"></i>
              <span className="font-medium">Dashboard</span>
            </Link>
            <Link href="/templates" className="flex items-center space-x-2 text-slate-400 hover:text-white transition-colors">
              <i className="ri-chat-3-line text-lg"></i>
              <span className="font-medium">Templates</span>
            </Link>
            <Link href="/analytics" className="flex items-center space-x-2 text-slate-400 hover:text-white transition-colors">
              <i className="ri-bar-chart-line text-lg"></i>
              <span className="font-medium">Analytics</span>
            </Link>
            <div className="flex items-center space-x-2 text-white">
              <i className="ri-vip-crown-fill text-lg"></i>
              <span className="font-medium">Plans</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/settings" className="flex items-center space-x-2 text-slate-400 hover:text-white transition-colors">
              <i className="ri-user-line text-lg"></i>
              <span className="font-medium">Account</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
