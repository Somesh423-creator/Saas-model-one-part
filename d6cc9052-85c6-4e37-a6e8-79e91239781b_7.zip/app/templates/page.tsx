
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Templates() {
  const [activeTemplate, setActiveTemplate] = useState('pdf');
  const [delayEnabled, setDelayEnabled] = useState(true);
  const [delayTime, setDelayTime] = useState(30);
  const [previewVisible, setPreviewVisible] = useState(false);

  const [templates, setTemplates] = useState([
    { id: 'pdf', trigger: 'PDF', reply: 'Here\\\\\\\'s the PDF you requested! 📚 Check your DMs for the download link. Let me know if you need anything else! ✨', emoji: '📚' },
    { id: 'pricing', trigger: 'price', reply: 'Thanks for your interest! 💖 Here are my current coaching packages. DM me "CALL" for a free 15-min consultation! 🎯', emoji: '💰' },
    { id: 'booking', trigger: 'book', reply: 'Yay! Let\\\\\\\'s get you booked! 🗓️ Click the link in my bio to see available slots. Can\\\\\\\'t wait to work with you! 💪', emoji: '📅' },
  ]);

  const currentTemplate = templates.find(t => t.id === activeTemplate);

  const updateTemplate = (field, value) => {
    setTemplates(prev => prev.map(template => 
      template.id === activeTemplate 
        ? { ...template, [field]: value }
        : template
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative">
      {/* Professional Floating Elements */}
      <div className="absolute top-24 right-6 animate-pulse">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-message-line text-blue-400 text-sm"></i>
        </div>
      </div>
      <div className="absolute top-40 left-8 animate-pulse delay-200">
        <div className="w-6 h-6 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <i className="ri-edit-line text-indigo-400 text-sm"></i>
        </div>
      </div>

      {/* Professional Header */}
      <div className="fixed top-0 w-full z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-700/50 px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/" className="w-8 h-8 flex items-center justify-center bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700">
              <i className="ri-arrow-left-line text-white text-lg"></i>
            </Link>
            <div>
              <h1 className="text-white font-bold text-lg">Template Manager</h1>
              <p className="text-slate-300 text-xs">Professional auto-reply templates</p>
            </div>
          </div>
          <button 
            onClick={() => setPreviewVisible(!previewVisible)}
            className="!rounded-button px-4 py-2 bg-slate-800/50 backdrop-blur-sm rounded-lg border border-slate-700"
          >
            <span className="text-white text-sm font-medium">Preview</span>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 pb-24 px-4 space-y-6">
        {/* Professional Template Selector */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
          <h2 className="text-white font-bold text-lg mb-4">Select Template</h2>
          <div className="grid grid-cols-3 gap-3">
            {templates.map((template) => (
              <button
                key={template.id}
                onClick={() => setActiveTemplate(template.id)}
                className={`!rounded-button p-4 rounded-xl transition-all duration-300 ${
                  activeTemplate === template.id 
                    ? 'bg-slate-700 border-2 border-blue-500/50 scale-105 shadow-lg' 
                    : 'bg-slate-800/50 border border-slate-700/50 hover:bg-slate-700/50'
                }`}
              >
                <div className="text-2xl mb-2">{template.emoji}</div>
                <p className="text-white text-sm font-medium">{template.trigger}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Professional Template Editor */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-bold">Edit Template</h3>
            <span className="px-3 py-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg text-white text-xs font-medium shadow-lg">
              {currentTemplate?.emoji} {currentTemplate?.trigger}
            </span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-slate-300 text-sm font-medium mb-2 block">Trigger Keyword</label>
              <input
                type="text"
                value={currentTemplate?.trigger || ''}
                onChange={(e) => updateTemplate('trigger', e.target.value)}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-400 backdrop-blur-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                placeholder="Enter keyword..."
              />
            </div>

            <div>
              <label className="text-slate-300 text-sm font-medium mb-2 block">Professional Auto-Reply Message</label>
              <textarea
                value={currentTemplate?.reply || ''}
                onChange={(e) => updateTemplate('reply', e.target.value)}
                rows={4}
                maxLength={500}
                className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-400 backdrop-blur-sm resize-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                placeholder="Write your professional auto-reply..."
              />
              <div className="flex justify-between items-center mt-2">
                <span className="text-slate-400 text-xs">Character limit: 500</span>
                <span className="text-slate-400 text-xs">{currentTemplate?.reply.length || 0}/500</span>
              </div>
            </div>
          </div>
        </div>

        {/* Professional Delay Settings */}
        <div className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-white font-bold">Response Timing</h3>
              <p className="text-slate-300 text-sm">Add professional delays to responses</p>
            </div>
            <div className="relative">
              <input 
                type="checkbox" 
                checked={delayEnabled}
                onChange={(e) => setDelayEnabled(e.target.checked)}
                className="sr-only peer" 
              />
              <div className="w-14 h-8 bg-slate-700 rounded-full peer peer-checked:bg-gradient-to-r peer-checked:from-blue-600 peer-checked:to-indigo-600 transition-all duration-300 border border-slate-600"></div>
              <div className="absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform duration-300 peer-checked:translate-x-6 shadow-lg"></div>
            </div>
          </div>

          {delayEnabled && (
            <div className="mt-4">
              <label className="text-slate-300 text-sm font-medium mb-2 block">Delay Duration (seconds)</label>
              <div className="flex items-center space-x-4">
                <input
                  type="range"
                  min="5"
                  max="180"
                  value={delayTime}
                  onChange={(e) => setDelayTime(Number(e.target.value))}
                  className="flex-1 h-2 bg-slate-700 rounded-full appearance-none slider"
                />
                <span className="text-white font-medium text-sm w-12 bg-slate-700 px-2 py-1 rounded-lg">{delayTime}s</span>
              </div>
            </div>
          )}
        </div>

        {/* Professional Preview Modal */}
        {previewVisible && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800/90 backdrop-blur-md rounded-2xl p-6 w-full max-w-sm border border-slate-700">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold">Professional Preview</h3>
                <button
                  onClick={() => setPreviewVisible(false)}
                  className="!rounded-button w-8 h-8 flex items-center justify-center bg-slate-700 rounded-lg border border-slate-600"
                >
                  <i className="ri-close-line text-white"></i>
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex justify-start">
                  <div className="bg-slate-700/70 rounded-2xl rounded-bl-md px-4 py-3 max-w-xs border border-slate-600/50">
                    <p className="text-slate-100 text-sm">{currentTemplate?.trigger}</p>
                    <p className="text-slate-400 text-xs mt-1">Just now</p>
                  </div>
                </div>

                <div className="flex justify-end">
                  <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl rounded-br-md px-4 py-3 max-w-xs shadow-lg">
                    <p className="text-white text-sm">{currentTemplate?.reply}</p>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="text-blue-200 text-xs">Auto-reply {delayEnabled ? `(${delayTime}s delay)` : ''}</span>
                      <div className="w-4 h-4 flex items-center justify-center">
                        <i className="ri-robot-line text-blue-200 text-xs"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Professional Bottom Navigation */}
      <div className="fixed bottom-0 w-full bg-slate-900/90 backdrop-blur-md border-t border-slate-700/50 px-4 py-3">
        <div className="grid grid-cols-4 gap-0">
          <Link href="/" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-home-5-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Dashboard</span>
          </Link>
          <div className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-chat-3-fill text-white text-lg"></i>
            </div>
            <span className="text-white text-xs mt-1 font-medium">Templates</span>
          </div>
          <Link href="/analytics" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-bar-chart-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Analytics</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center py-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-user-line text-slate-400 text-lg"></i>
            </div>
            <span className="text-slate-400 text-xs mt-1">Account</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
